/* Functions that model the motion of an object. */

double calculate_velocity(double initial_v, double accel, double time);
